namespace fNbt.Serialization {
    public enum MissingPolicy {
        Default = 0,
        Error = 0,
        Ignore = 1
    }
}