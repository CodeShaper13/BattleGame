using System;

namespace fNbt.Serialization {
    public class NbtIgnoreAttribute : Attribute {}
}
